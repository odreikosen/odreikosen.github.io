package SPLT_A4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SPLT implements SPLT_Interface{
  private BST_Node root;
  private int size;
  
  public SPLT() {
    this.size = 0;
  } 
  
  public BST_Node getRoot() { //please keep this in here! I need your root node to test your tree!
    return root;
  }

@Override
public void insert(String s) {
	if(empty()) {
		root=new BST_Node(s,null,null,null);
		size++;
		return;
	}
	
	root=root.insertNode(s);
	if(root.justMade) {
		size++;
	}
	return;
	
	
}

@Override
public void remove(String s) {
	boolean hello=contains(s);
if(!hello) {
	return;
}
size--;
if(size==0) {
	return;
}
BST_Node temp=root.right;
BST_Node temp1=root.left;
if(temp1!=null) {
	temp1.parent=null;
root=temp1.findMax();
root.right=temp;
if(temp!=null) {
temp.parent=root;
}return;
}  else {
	if (temp!=null) {
	temp.parent=null;
	}
	root=temp;
}
	return;
}

@Override
public String findMin() {
	if(empty()) {
	return null;
}
	root=root.findMin();
	return root.data;
}

@Override
public String findMax() {
	if(empty()) {
	return null;
}
	root=root.findMax();
	return root.data;
}


@Override
public boolean empty() {
	if(size==0) {
		return true;
	}
	return false;
}

@Override
public boolean contains(String s) {
	if((empty())) {
		return false;
	}
	root=root.containsNode(s);
	if(root.justMade) {
		return true;
	}
	return false;
}

@Override
public int size() {
	// TODO Auto-generated method stub
	return size;
}

@Override
public int height() {
	if(empty()) {
		return -1;
	}
	return root.getHeight();
}  
}