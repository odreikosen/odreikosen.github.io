package a9;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class PixelInspectorUI extends JPanel {
	private Pixel current;
	private JLabel x_label;
	private JLabel y_label;
	private JLabel pixel_info;
	private ImageEditorView view;
	private ImageEditorController con;
	public PixelInspectorUI(ImageEditorView views,ImageEditorModel model,ImageEditorController cont) {
		con=cont;
		x_label = new JLabel("X: ");
		y_label = new JLabel("Y: ");
		pixel_info = new JLabel("(r,g,b)");
		view=views;
		setLayout(new GridLayout(4,1));
		JButton copy=new JButton("Copy Pixel to PaintBrush");
		copy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {			
			/*con.setTool(paint);*/
			cont.switc();
			view.getToolWidget().setTool();
			/*view.installToolUI(paint.getUI());
			con.toolChosen("Copy");*/
		
			}
		});
		
		add(x_label);
		add(y_label);
		add(pixel_info);
		add(copy);
		copy.setVisible(true);
	}
	
	public void setInfo(int x, int y, Pixel p) {
		current=p;
	x_label.setText("X: " + x);
		y_label.setText("Y: " + y);
		pixel_info.setText(String.format("(%3.2f, %3.2f, %3.2f)", p.getRed(), p.getBlue(), p.getGreen()));		
	}

	public double getRed() {
	try {
		return current.getRed();
	} catch(Exception e) {
		JOptionPane.showMessageDialog(this,"No Pixel Clicked");
		return .5;
	}
	
	}
	public double getGreen() {
		try{
			return current.getGreen();
		} catch(Exception e) {
			
			return .5;
		}
		
	}
	public double getBlue() {
		try {
		return current.getBlue();
	} catch(Exception e) {
		return .5;
	}
}
}
