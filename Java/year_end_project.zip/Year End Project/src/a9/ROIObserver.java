package a9;

public interface ROIObserver {
	
	void notify(ObservablePicture picture, Region r);
}
