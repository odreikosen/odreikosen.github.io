package a9;

public interface RegisteredROIObserver extends ROIObserver {

	Region getROI();
	ROIObserver getObserver();

}
