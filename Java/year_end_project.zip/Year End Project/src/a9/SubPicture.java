package a9;

public interface SubPicture extends Picture {

	Picture getSource();
	int getXOffset();
	int getYOffset();
}
