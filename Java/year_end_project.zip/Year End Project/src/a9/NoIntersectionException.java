package a9;

public class NoIntersectionException extends Exception {

	public NoIntersectionException() {
		super("Empty intersection");
	}
}
