package a9;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class ImageEditor {
	public static void main(String[] args) throws IOException {
		CardLayout card=new CardLayout();
		Picture f = PictureImpl.readFromURL("https://pbs.twimg.com/profile_images/634871395093078016/M6o38ewN_400x400.jpg");

		JFrame main_frame = new JFrame();
		main_frame.setTitle("Assignment 9 Image Editor");
		main_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		ImageEditorModel model = new ImageEditorModel(f);
		ImageEditorView view = new ImageEditorView(main_frame, model);
 		ImageEditorController controller = new ImageEditorController(view, model);
		JPanel top=new JPanel(new BorderLayout());
 		JPanel main=new JPanel(card);
 	
		JPanel top_panel = new JPanel();
		top_panel.setLayout(new BorderLayout());
		top_panel.add(view, BorderLayout.CENTER);
		JButton url=new JButton("Open New Picture From URL");
	 	url.addActionListener(new ActionListener() {
	 		String se;
	 		public void actionPerformed(ActionEvent e) {
	 			se=JOptionPane.showInputDialog("Enter URL");
	 			Picture pic = null;
	 			try {
					pic=PictureImpl.readFromURL(se);
					ImageEditorModel model = new ImageEditorModel(pic);
		 			ImageEditorView view = new ImageEditorView(main_frame, model);
		 	 		ImageEditorController controller = new ImageEditorController(view, model);
		 	 		JPanel pan=new JPanel(new BorderLayout());
		 	 		pan.add(view);
		 	 		main.add(pan);
		 	 		card.next(main);
		 	 		main_frame.pack();
				} catch (IOException e1) {
					System.out.println("Invalid URL");

				}
	 			
	 		}
	 	});
top.add(url,BorderLayout.SOUTH);

url.setVisible(true);
		main.add(top_panel);
		top.add(main,BorderLayout.CENTER);
		main_frame.setContentPane(top);
		main_frame.pack();
		main_frame.setVisible(true);
	}
}