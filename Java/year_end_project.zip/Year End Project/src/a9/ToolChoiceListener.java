package a9;

public interface ToolChoiceListener {

	void toolChosen(String tool_name);
}
