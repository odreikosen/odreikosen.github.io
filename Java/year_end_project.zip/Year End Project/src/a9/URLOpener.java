package a9;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class URLOpener extends JPanel{
	
	private String s;
	
	public URLOpener() {
		 	JButton url=new JButton("Open New Picture From URL");
		 	url.addActionListener(new ActionListener() {
		 		public void actionPerformed(ActionEvent e) {
		 			s=JOptionPane.showInputDialog("Enter URL");
		 		}
		 	});
	add(url);
	url.setVisible(true);
	}
	


public void setURL(String u) {
	s=u;
}
}